<?php
// This file is part of Level Up XP.
//
// Level Up XP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Level Up XP is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Level Up XP.  If not, see <https://www.gnu.org/licenses/>.
//
// https://levelup.plus

/**
 * User state.
 *
 * @package    block_xp
 * @copyright  2017 Frédéric Massart
 * @author     Frédéric Massart <fred@branchup.tech>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_xp\local\xp;

use block_xp\local\utils\user_utils;
use moodle_url;
use renderable;
use stdClass;

class user_state implements renderable, state, state_with_subject, state_with_user {

    protected $courseid;
    protected $user;
    protected $xp;
    protected $levelsinfo;
    protected $level;
    protected $nextlevel;
    
    // 成绩缓存
    protected $cachedgrade = null;           // 缓存百分比成绩
    protected $cachedrawgrade = null;        // 缓存原始成绩（真实成绩）
    protected $cachedmaxgrade = null;        // 缓存最高分
    protected $preloaded_raw_grade = null;   // 预加载的原始成绩（避免重复查询）

    public function __construct(stdClass $user, $xp, levels_info $levelsinfo, $courseid = null) {
        $this->user = $user;
        $this->xp = $xp;
        $this->levelsinfo = $levelsinfo;
        $this->courseid = !empty($courseid) ? $courseid : SITEID;
    }

    public function get_id() {
        return $this->user->id;
    }

    public function get_level() {
        if (!$this->level) {
            $xp = $this->get_xp();
            $this->level = $this->levelsinfo->get_level_from_xp($xp);
        }
        return $this->level;
    }

    public function get_link() {
        $userid = $this->user->id;
        $profileurl = new moodle_url('/user/profile.php', ['id' => $userid]);
        if ($this->courseid != SITEID) {
            $profileurl = new moodle_url('/user/view.php', ['id' => $userid, 'course' => $this->courseid]);
        }
        return $profileurl;
    }

    public function get_name() {
        return fullname($this->user);
    }

    public function get_picture() {
        return user_utils::user_picture($this->user);
    }

    public function get_ratio_in_level() {
        $total = $this->get_total_xp_in_level();
        if ($total <= 0) return 1;
        return min(1, max(0, $this->get_xp_in_level() / $total));
    }

    public function get_total_xp_in_level() {
        $level = $this->get_level()->get_level();

        if ($level === 1) {
            return 20;
        } else if ($level === 10) {
            return 0;
        } else {
            return 10;
        }
    }

    public function get_user() {
        return $this->user;
    }

    /**
     * 获取XP（百分比成绩，0-100）
     * 用于等级计算和排名
     *
     * @return int 百分比成绩
     */
    public function get_xp() {
        if ($this->cachedgrade !== null) return $this->cachedgrade;
        $this->cachedgrade = $this->load_relative_grade_from_gradebook();
        return $this->cachedgrade;
    }

    public function get_xp_in_level() {
        $xp = $this->get_xp();
        $level = $this->get_level()->get_level();

        // 1级 0-19
        if ($level === 1) {
            return $xp;
        }

        // 2级～9级：每级都是 10 分区间
        // 2级=20+, 3级=30+, 4级=40+, 5级=50+ ...
        $base = $level * 10;
        return $xp - ($base - 10);
    }

    protected function get_next_level() {
        if ($this->nextlevel === null) {
            $levelnum = $this->get_level()->get_level();
            $count = $this->levelsinfo->get_count();
            $this->nextlevel = ($levelnum >= $count) ? false : $this->levelsinfo->get_level($levelnum + 1);
        }
        return $this->nextlevel ?: null;
    }

    /**
     * 从成绩单加载相对成绩（百分比）
     *
     * @return int 百分比成绩 (0-100)
     */
    protected function load_relative_grade_from_gradebook() {
        global $DB;

        if ($this->courseid == SITEID) return 0;

        $sql = "SELECT gg.finalgrade
                FROM {grade_grades} gg
                JOIN {grade_items} gi ON gi.id = gg.itemid
                WHERE gg.userid = :userid
                  AND gi.courseid = :courseid
                  AND gi.itemtype = 'course'
                  AND gg.finalgrade IS NOT NULL";

        $usergrade = $DB->get_field_sql($sql, [
            'userid' => $this->get_id(),
            'courseid' => $this->courseid
        ]);

        if ($usergrade === false) return 0;

        $sqlmax = "SELECT MAX(gg.finalgrade)
                   FROM {grade_grades} gg
                   JOIN {grade_items} gi ON gi.id = gg.itemid
                   WHERE gi.courseid = :courseid
                     AND gi.itemtype = 'course'
                     AND gg.finalgrade IS NOT NULL";

        $maxgrade = $DB->get_field_sql($sqlmax, ['courseid' => $this->courseid]);

        if ($maxgrade <= 0) return 0;

        return min(100, round($usergrade / $maxgrade * 100));
    }

    /**
     * 设置预加载的原始成绩（避免重复查询数据库）
     * 由 leaderboard 调用，传入已查询的原始成绩
     *
     * @param float $rawGrade 原始成绩
     */
    public function set_preloaded_raw_grade($rawGrade) {
        $this->preloaded_raw_grade = $rawGrade;
    }

    /**
     * 获取真实成绩（原始分数）
     * 优先使用预加载的值，如果没有则从数据库加载
     *
     * @return float|null 原始成绩，如果没有则返回null
     */
    public function get_raw_grade() {
        // 优先使用预加载的成绩
        if ($this->preloaded_raw_grade !== null) {
            return $this->preloaded_raw_grade;
        }
        
        // 没有预加载，尝试从缓存获取
        if ($this->cachedrawgrade !== null) {
            return $this->cachedrawgrade;
        }
        
        // 从数据库加载
        $this->load_grade_data();
        return $this->cachedrawgrade;
    }

    /**
     * 获取课程最高分
     *
     * @return float|null 最高分，如果没有则返回null
     */
    public function get_max_grade() {
        if ($this->cachedmaxgrade !== null) return $this->cachedmaxgrade;
        $this->load_grade_data();
        return $this->cachedmaxgrade;
    }

    /**
     * 加载成绩数据（原始成绩和最高分）
     * 一次性加载两个值，减少数据库查询
     */
    protected function load_grade_data() {
        global $DB;

        if ($this->courseid == SITEID) {
            $this->cachedrawgrade = null;
            $this->cachedmaxgrade = null;
            return;
        }

        $sql = "SELECT gg.finalgrade, 
                       (SELECT MAX(gg2.finalgrade)
                        FROM {grade_grades} gg2
                        JOIN {grade_items} gi2 ON gi2.id = gg2.itemid
                        WHERE gi2.courseid = :courseid2
                          AND gi2.itemtype = 'course'
                          AND gg2.finalgrade IS NOT NULL) as maxgrade
                FROM {grade_grades} gg
                JOIN {grade_items} gi ON gi.id = gg.itemid
                WHERE gg.userid = :userid
                  AND gi.courseid = :courseid
                  AND gi.itemtype = 'course'
                  AND gg.finalgrade IS NOT NULL";

        $record = $DB->get_record_sql($sql, [
            'userid' => $this->get_id(),
            'courseid' => $this->courseid,
            'courseid2' => $this->courseid
        ]);

        if ($record && isset($record->finalgrade)) {
            $this->cachedrawgrade = floatval($record->finalgrade);
            $this->cachedmaxgrade = isset($record->maxgrade) ? floatval($record->maxgrade) : null;
        } else {
            $this->cachedrawgrade = null;
            $this->cachedmaxgrade = null;
        }
    }

    /**
     * 检查是否有真实成绩
     *
     * @return bool
     */
    public function has_raw_grade() {
        $raw = $this->get_raw_grade();
        return $raw !== null;
    }

    /**
     * 获取格式化的真实成绩（带小数位）
     *
     * @param int $decimals 小数位数
     * @return string
     */
    public function get_formatted_raw_grade($decimals = 2) {
        $grade = $this->get_raw_grade();
        if ($grade === null) {
            return '-';
        }
        return number_format($grade, $decimals);
    }

    /**
     * 获取格式化的百分比成绩
     *
     * @return string
     */
    public function get_formatted_percentage() {
        return $this->get_xp() . '%';
    }

}
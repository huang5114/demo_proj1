<?php
// This file is part of Level Up XP.
//
// Level Up XP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Level Up XP is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Level Up XP.  If not, see <https://www.gnu.org/licenses/>.
//
// https://levelup.plus

/**
 * Course user state leaderboard.
 *
 * @package    block_xp
 * @copyright  2018 Frédéric Massart
 * @author     Frédéric Massart
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_xp\local\leaderboard;

use context_helper;
use moodle_database;
use stdClass;
use block_xp\local\iterator\map_recordset;
use block_xp\local\sql\limit;
use block_xp\local\userfilter\group_members;
use block_xp\local\userfilter\user_filter;
use block_xp\local\utils\user_utils;
use block_xp\local\xp\levels_info;
use block_xp\local\xp\state;
use block_xp\local\xp\state_rank;
use block_xp\local\xp\user_state;

class course_user_leaderboard implements leaderboard {

    protected $columns;
    protected $db;
    protected $course;
    protected $courseid;
    protected $levelsinfo;
    protected $ranker;
    protected $table = 'block_xp';
    protected $userfilter;

    protected $fields;
    protected $from;
    protected $where = '';
    protected $order;
    protected $params = [];

    protected $groupid = 0;

    public function __construct(
        moodle_database $db,
        levels_info $levelsinfo,
        $courseid,
        array $columns,
        ?ranker $ranker = null,
        $groupid = 0
    ) {
        $this->db = $db;
        $this->levelsinfo = $levelsinfo;
        $this->courseid = $courseid;
        $this->ranker = $ranker;
        $this->columns = $columns;
        $this->groupid = $groupid;

        if (!empty($groupid)) {
            debugging('The $groupid argument of the leaderboard is deprecated, use set_user_filter() instead.', DEBUG_DEVELOPER);
            $this->set_user_filter(new group_members($groupid));
        }
    }

    protected function prepare_query() {
        if (!empty($this->from)) {
            return;
        }

        $initialwhere = $this->where;
        $initialparams = $this->params;
        $params = [];

        $this->fields = 'u.id as userid, ' .
            'gg.finalgrade as grade, ' .
            user_utils::picture_fields('u', 'useridunused') . ', ' .
            context_helper::get_preload_record_columns_sql('ctx');

        $this->from = "{user} u
              JOIN {grade_grades} gg ON gg.userid = u.id
              JOIN {grade_items} gi ON gi.id = gg.itemid
              JOIN {context} ctx ON ctx.instanceid = u.id
                   AND ctx.contextlevel = :contextlevel";
        $params['contextlevel'] = CONTEXT_USER;

        $this->where = "u.deleted = 0 AND u.suspended = 0 AND gi.courseid = :courseid
                    AND gi.itemtype = 'course'
                    AND gg.finalgrade IS NOT NULL";
        $params['courseid'] = $this->courseid;

        [$usersql, $userparams] = $this->get_user_ids_sql('u.id');
        $this->where .= " AND ($usersql)";
        $params = array_merge($params, $userparams);

        if ($initialwhere) {
            $this->where .= ' AND ' . $initialwhere;
        }
        if (!empty($initialparams)) {
            $params = array_merge($params, $initialparams);
        }

        $this->order = "gg.finalgrade DESC, u.id ASC";
        $this->params = $params;
    }

    public function get_columns() {
        return $this->columns;
    }

    public function get_count() {
        $this->prepare_query();
        $sql = "SELECT COUNT(*) FROM {$this->from} WHERE {$this->where}";
        return $this->db->count_records_sql($sql, $this->params);
    }

    protected function get_points($id) {
        $this->prepare_query();
        $sql = "SELECT gg.finalgrade
                  FROM {$this->from}
                 WHERE {$this->where} AND u.id = :userid";
        return $this->db->get_field_sql($sql, $this->params + ['userid' => $id]);
    }

    public function get_position($id) {
        $xp = $this->get_points($id);
        return $xp === false ? null : $this->get_position_with_xp($id, $xp);
    }

    protected function get_position_with_xp($id, $grade) {
        $this->prepare_query();
        $sql = "SELECT COUNT(*)
                  FROM {$this->from}
                 WHERE {$this->where}
                   AND (gg.finalgrade > :posgrade OR (gg.finalgrade = :posgradeeq AND u.id < :posid))";
        $params = $this->params + [
            'posgrade' => $grade,
            'posgradeeq' => $grade,
            'posid' => $id
        ];
        return $this->db->count_records_sql($sql, $params);
    }

    public function get_rank($id) {
        $state = $this->get_state($id);
        if (!$state) {
            return null;
        }
        if ($this->ranker) {
            return $this->ranker->rank_state($state);
        }
        $rank = $this->get_rank_from_xp($state->get_raw_grade());
        return new state_rank($rank, $state);
    }

    protected function get_rank_from_xp($grade) {
        $grade = (float)$grade;
        $this->prepare_query();
        $sql = "SELECT COUNT(*) FROM {$this->from} WHERE {$this->where} AND gg.finalgrade > :posgrade";
        return $this->db->count_records_sql($sql, $this->params + ['posgrade' => $grade]) + 1;
    }

    /**
     * 获取排名 - 修复浮点数隐式转换问题
     */
  public function get_ranking(limit $limit) {
    $recordset = $this->get_ranking_recordset($limit);

    if ($this->ranker) {
        return $this->ranker->rank_states(
            new map_recordset($recordset, function ($record) {
                return $this->make_state_from_record($record);
            })
        );
    }

    // 先收集所有记录
    $records = [];
    foreach ($recordset as $record) {
        $records[] = $record;
    }
    $recordset->close();

    if (empty($records)) {
        return [];
    }

    // 获取所有唯一分数（四舍五入到2位小数，避免精度问题）
    $uniqueScoresMap = [];
    foreach ($records as $record) {
        $grade = (float)$record->grade;
        $roundedGrade = round($grade, 2);  // 关键：四舍五入到2位小数
        $uniqueScoresMap[(string)$roundedGrade] = $roundedGrade;
    }
    $uniqueScores = array_values($uniqueScoresMap);
    rsort($uniqueScores);

    // 计算每个分数与前一个不同分数的差距
    $scoreGapMap = [];
    $prevScore = null;
    foreach ($uniqueScores as $index => $score) {
        $scoreKey = (string)$score;
        if ($index == 0) {
            $scoreGapMap[$scoreKey] = null; // 最高分
        } else {
            $scoreGapMap[$scoreKey] = round($prevScore - $score, 2);
        }
        $prevScore = $score;
    }

    // 构建排名
    $rank = null;
    $lastrealgrade = null;
    $ranking = [];

    foreach ($records as $record) {
        $state = $this->make_state_from_record($record);
        $realgrade = (float)$record->grade;
        $roundedGrade = round($realgrade, 2);  // 使用四舍五入后的值匹配

        if ($rank === null || abs($lastrealgrade - $roundedGrade) > 0.01) {
            $rank = $this->get_rank_from_xp($realgrade);
            $lastrealgrade = $roundedGrade;
        }

        $stateRank = new state_rank($rank, $state);
        
        $gradeKey = (string)$roundedGrade;
        $gap = $scoreGapMap[$gradeKey] ?? null;
        $stateRank->diff_to_previous = $gap !== null ? (float)$gap : null;

        $ranking[] = $stateRank;
    }

    return $ranking;
}

    protected function get_ranking_recordset(limit $limit) {
        $this->prepare_query();
        $sql = "SELECT {$this->fields} FROM {$this->from} WHERE {$this->where} ORDER BY {$this->order}";
        return $limit ?
            $this->db->get_recordset_sql($sql, $this->params, $limit->get_offset(), $limit->get_count()) :
            $this->db->get_recordset_sql($sql, $this->params);
    }

    protected function get_state($id) {
        $this->prepare_query();
        $sql = "SELECT {$this->fields} FROM {$this->from} WHERE {$this->where} AND u.id = :userid";
        $record = $this->db->get_record_sql($sql, $this->params + ['userid' => $id]);
        
        if (!$record) {
            return null;
        }
        
        return $this->make_state_from_record($record);
    }

    protected function get_user_ids_sql(string $useridalias) {
        if (!$this->userfilter) {
            return ['1=1', []];
        }
        return $this->userfilter->get_sql($useridalias);
    }

    protected function make_state_from_record(stdClass $record, $useridfield = 'userid') {
        $user = user_utils::unalias_picture_fields($record, $useridfield);
        context_helper::preload_from_record($record);
        
        $state = new user_state($user, 0, $this->levelsinfo, $this->courseid);
        
        if (isset($record->grade)) {
            $state->set_preloaded_raw_grade($record->grade);
        }
        
        return $state;
    }

    public function set_user_filter(user_filter $filter) {
        $this->userfilter = $filter;
    }

}
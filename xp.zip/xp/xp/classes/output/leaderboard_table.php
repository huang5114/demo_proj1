<?php
// This file is part of Level Up XP.
//
// Level Up XP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Level Up XP is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Level Up XP.  If not, see <https://www.gnu.org/licenses/>.
//
// https://levelup.plus

/**
 * Leaderboard table.
 *
 * @package    block_xp
 * @copyright  2018 Frédéric Massart
 * @author     Frédéric Massart
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_xp\output;

defined('MOODLE_INTERNAL') || die();
require_once($CFG->libdir . '/tablelib.php');

use block_xp\local\config\course_world_config;
use block_xp\local\config\immutable_config;
use block_xp\local\config\static_config;
use block_xp\local\leaderboard\leaderboard;
use block_xp\local\routing\url;
use block_xp\local\sql\limit;
use block_xp\local\xp\state_with_subject;
use flexible_table;
use html_writer;
use paging_bar;
use renderer_base;

class leaderboard_table extends flexible_table {

    protected $context;
    protected $canviewprofiles = false;
    protected $discardcolumns = [];
    protected $columnsdefinition;
    protected $config;
    protected $leaderboard;
    protected $xpoutput = null;
    protected $userid;
    protected $identitymode = course_world_config::IDENTITY_ON;
    protected $rankmode = course_world_config::RANK_ON;
    protected $showpagesizeselector = false;
    protected $fence;

    public function __construct(
        leaderboard $leaderboard,
        renderer_base $renderer,
        array $options,
        $userid
    ) {
        global $PAGE;
        parent::__construct('block_xp_ladder');

        $this->userid = $userid;
        $this->leaderboard = $leaderboard;
        $this->xpoutput = $renderer;
        $this->config = new immutable_config($options['config'] ?? new static_config());

        if (isset($options['context'])) {
            $this->context = $options['context'];
        } else {
            $this->context = $PAGE->context;
        }

        $optionkeys = ['rankmode', 'identitymode'];
        foreach ($optionkeys as $optionkey) {
            if ($this->config->has($optionkey)) {
                $this->{$optionkey} = $this->config->get($optionkey);
            } else if (isset($options[$optionkey])) {
                $this->{$optionkey} = $options[$optionkey];
            }
        }

        if (isset($options['fence'])) {
            $this->fence = $options['fence'];
        }
        if (isset($options['discardcolumns'])) {
            $this->discardcolumns = $options['discardcolumns'];
        }

        $this->canviewprofiles = has_capability('moodle/user:viewdetails', $this->context);
        $this->init();
    }

    protected function init(): void {
        $columns = [];
        $columns['rank'] = get_string('rank', 'block_xp');
        $columns['level'] = get_string('level', 'block_xp');
        $columns['fullname'] = 'Participant';
        $columns['xp'] = 'Total';
        $columns['realgrade'] = 'Real Grade';
        $columns['gradediff'] = 'Gap';
        
        if (!isset($this->discardcolumns['actions'])) {
            $columns['actions'] = '';
        }
        
        $this->define_columns(array_keys($columns));
        $this->define_headers(array_values($columns));

        $this->sortable(false);
        $this->collapsible(false);
        $this->set_attribute('class', 'block_xp-table');
        $this->column_class('rank', 'col-rank');
        $this->column_class('level', 'col-lvl');
        $this->column_class('fullname', 'col-fullname');
        $this->column_class('xp', 'col-xp');
        $this->column_class('realgrade', 'col-realgrade');
        $this->column_class('gradediff', 'col-gradediff');
        $this->column_class('actions', 'col-actions');
    }

    protected function generate_columns_definition(): array {
        $leaderboardcols = array_diff_key($this->leaderboard->get_columns(), $this->discardcolumns);
        if (isset($leaderboardcols['progress'])) {
            unset($leaderboardcols['progress']);
        }
        return $leaderboardcols;
    }

    final protected function get_columns_definition() {
        if (!isset($this->columnsdefinition)) {
            $this->columnsdefinition = $this->generate_columns_definition();
        }
        return $this->columnsdefinition;
    }

    protected function get_row_actions($row) {
        return [];
    }

    public function out($pagesize) {
        $this->setup();

        if ($this->is_downloading()) {
            $limit = new limit(0);
        } else if (empty($this->fence)) {
            $requestedpage = optional_param($this->request[TABLE_VAR_PAGE], null, PARAM_INT);
            if ($requestedpage === null) {
                $mypos = $this->leaderboard->get_position($this->userid);
                if ($mypos !== null) {
                    $this->currpage = floor($mypos / $pagesize);
                }
            }
            $this->pagesize($pagesize, $this->leaderboard->get_count());
            $limit = new limit($pagesize, (int) $this->get_page_start());
        } else {
            $this->pagesize($this->fence->get_count(), $this->fence->get_count());
            $limit = $this->fence;
        }

        $ranking = $this->leaderboard->get_ranking($limit);
        foreach ($ranking as $rank) {
            $classes = ($this->userid == $rank->get_state()->get_id()) ? 'highlight-row' : '';
            $this->add_data_keyed($this->rank_to_keyed_data($rank), $classes);
        }
        $this->finish_output();
    }

    protected function col_actions($row) {
        $actions = $this->get_row_actions($row);
        if (empty($actions)) {
            return '';
        }
        return $this->xpoutput->control_menu($actions);
    }

    public function col_fullname($row) {
        $o = $this->col_userpic($row);
        $link = null;
        $name = null;
        $state = $row->state;
        if ($state instanceof state_with_subject) {
            $link = $state->get_link();
            $name = $state->get_name();
        }
        $name = empty($name) ? '?' : $name;
        if ($link && $this->canviewprofiles) {
            $o .= html_writer::link($link->out(false), $name);
        } else {
            $o .= $name;
        }
        return $o;
    }

    public function col_lvl($row) {
        return $this->xpoutput->small_level_badge($row->state->get_level());
    }

    public function col_progress($row) {
        return $this->xpoutput->progress_bar($row->state);
    }

    public function col_realgrade($row) {
        $grade = $row->state->get_raw_grade();
        return $grade !== null ? number_format($grade, 2) : '-';
    }

    public function col_gradediff($row) {
        if ($row->rank == 1) {
            return '👑 No.1';
        }
        $diff = $row->diff_to_previous ?? null;
        if ($diff === null) {
            return '—';
        }
        $symbol = $diff >= 0 ? '+' : '';
        return $symbol . number_format($diff, 2);
    }

    public function col_rank($row) {
        if ($this->rankmode == course_world_config::RANK_REL) {
            $symbol = '';
            if ($row->rank > 0) {
                $symbol = '+';
            }
            return $symbol . $this->xpoutput->xp($row->rank);
        }
        return $row->rank;
    }

    public function col_xp($row) {
        return number_format($row->state->get_xp(), 2);
    }

    public function col_userpic($row) {
        $picture = null;
        $link = null;
        $state = $row->state;
        if ($state instanceof state_with_subject) {
            $picture = $state->get_picture();
            $link = $this->canviewprofiles ? $state->get_link() : null;
        }
        return $this->xpoutput->user_avatar($picture, $link);
    }

    public function start_html() {
        if (in_array(TABLE_P_TOP, $this->showdownloadbuttonsat)) {
            echo $this->download_buttons();
        }
        $this->wrap_html_start();
        echo html_writer::start_tag('div', ['class' => 'no-overflow']);
        echo html_writer::start_tag('table', $this->attributes);
    }

    public function finish_html() {
        if (!$this->started_output) {
            $this->print_nothing_to_display();
        } else {
            $emptyrow = array_fill(0, count($this->columns), '');
            while ($this->currentrow < $this->pagesize) {
                $this->print_row($emptyrow, 'emptyrow');
            }
            echo html_writer::end_tag('tbody');
            echo html_writer::end_tag('table');
            echo html_writer::end_tag('div');
            $this->wrap_html_finish();

            if (in_array(TABLE_P_BOTTOM, $this->showdownloadbuttonsat)) {
                echo $this->download_buttons();
            }

            $url20 = new url($this->baseurl);
            $url50 = new url($this->baseurl);
            $url100 = new url($this->baseurl);
            $url20->param('pagesize', 20);
            $url50->param('pagesize', 50);
            $url100->param('pagesize', 100);

            if ($this->use_pages) {
                if ($this->showpagesizeselector && $this->totalrows > 20) {
                    echo $this->xpoutput->pagesize_selector([
                        [20, $url20],
                        [50, $url50],
                        [100, $url100],
                    ], $this->pagesize);
                }
                $pagingbar = new paging_bar($this->totalrows, $this->currpage, $this->pagesize, $this->baseurl);
                $pagingbar->pagevar = $this->request[TABLE_VAR_PAGE];
                echo $this->xpoutput->render($pagingbar);
            }
        }
    }

    public function print_nothing_to_display() {
        echo \html_writer::div(
            \block_xp\di::get('renderer')->notification_without_close(
                get_string('ladderempty', 'block_xp'),
                'info'
            ),
            '',
            ['style' => 'margin: 1em 0']
        );
    }

    protected function rank_to_keyed_data($rank) {
        $row = (object) [
            'rank' => $rank->get_rank(),
            'state' => $rank->get_state(),
            'diff_to_previous' => $rank->diff_to_previous ?? null,
        ];
        
        return [
            'rank' => $this->col_rank($row),
            'level' => $this->col_lvl($row),
            'fullname' => $this->col_fullname($row),
            'xp' => $this->col_xp($row),
            'realgrade' => $this->col_realgrade($row),
            'gradediff' => $this->col_gradediff($row),
            'actions' => $this->col_actions($row),
        ];
    }

    public function show_pagesize_selector($value) {
        $this->showpagesizeselector = $value;
    }

}
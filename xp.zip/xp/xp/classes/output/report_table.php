<?php
// This file is part of Level Up XP.
//
// Level Up XP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Level Up XP is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Level Up XP.  If not, see <https://www.gnu.org/licenses/>.
//
// https://levelup.plus

/**
 * Block XP report table.
 *
 * @package    block_xp
 * @copyright  2014 Frédéric Massart
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_xp\output;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->libdir . '/tablelib.php');

use action_menu_link;
use context_course;
use context_helper;
use moodle_database;
use moodle_url;
use pix_icon;
use renderer_base;
use stdClass;
use table_sql;
use block_xp\di;
use block_xp\local\course_world;
use block_xp\local\permission\access_logs_permissions;
use block_xp\local\routing\url_resolver;
use block_xp\local\utils\user_utils;
use block_xp\local\xp\course_user_state_store;
use block_xp\local\xp\state_with_subject;

class report_table extends table_sql {

    protected $db;
    protected $world = null;
    protected $store = null;
    protected $logaccessperms = null;
    protected $renderer = null;
    protected $urlresolver;
    protected $groupid = null;
    protected $columnsdefinition;
    
    // 缓存差距数据
    protected $gaps = [];

    public function __construct(
        moodle_database $db,
        course_world $world,
        renderer_base $renderer,
        course_user_state_store $store,
        $groupid
    ) {
        parent::__construct('block_xp_report');
        $this->db = $db;
        $this->groupid = $groupid;
        $this->world = $world;
        $this->renderer = $renderer;
        $this->store = $store;
        $this->urlresolver = di::get('url_resolver');

        $accessperms = $this->world->get_access_permissions();
        if ($accessperms instanceof access_logs_permissions) {
            $this->logaccessperms = $accessperms;
        }

        $this->init();
    }

    protected function init() {
        $columnsdef = $this->get_columns_definition();
        $this->define_columns(array_keys($columnsdef));
        $this->define_headers(array_values($columnsdef));

        $this->sortable(true, 'realgrade', SORT_DESC);
        $this->no_sorting('userpic');
        $this->no_sorting('total');
        $this->no_sorting('gap');
        $this->collapsible(false);
        $this->set_attribute('class', 'block_xp-report-table');
        $this->column_class('userpic', 'col-userpic');
        $this->column_class('actions', 'col-actions');
    }

    protected function init_sql() {
        global $DB;

        $courseid = $this->world->get_courseid();
        $context = context_course::instance($courseid);
        $groupid = $this->groupid;

        [$enrolledsql, $enrolledparams] = get_enrolled_sql($context, 'block/xp:earnxp', $groupid);
        [$usersql, $userparams] = $this->generate_user_filter_sql();

        $sqlmax = "SELECT MAX(gg.finalgrade)
                   FROM {grade_grades} gg
                   JOIN {grade_items} gi ON gi.id = gg.itemid
                   WHERE gi.courseid = :cid AND gi.itemtype = 'course' AND gg.finalgrade IS NOT NULL";
        $maxgrade = $DB->get_field_sql($sqlmax, ['cid' => $courseid]);
        
        // 确保 maxgrade 是整数
        $maxgrade = (float) $maxgrade;
        if ($maxgrade <= 0) {
            $maxgrade = 100;
        } else {
            $maxgrade = (int) round($maxgrade);
        }

        $this->sql = new stdClass();
        
        $this->sql->fields = user_utils::picture_fields('u') . ', u.idnumber, u.email, u.username, u.suspended,
                             grade_sub.finalgrade AS realgrade,
                             COALESCE(ROUND((grade_sub.finalgrade / :maxgrade) * 100, 2), 0) as total, ' .
                             context_helper::get_preload_record_columns_sql('ctx');

        $this->sql->from = "{user} u
                       JOIN {context} ctx ON ctx.instanceid = u.id AND ctx.contextlevel = :clevel
                       LEFT JOIN (
                           SELECT gg.userid, gg.finalgrade
                           FROM {grade_grades} gg
                           JOIN {grade_items} gi ON gi.id = gg.itemid
                           WHERE gi.courseid = :courseid 
                             AND gi.itemtype = 'course'
                             AND gg.finalgrade IS NOT NULL
                           GROUP BY gg.userid
                       ) grade_sub ON grade_sub.userid = u.id";

        $this->sql->where = "u.deleted = 0
                        AND u.id IN ($enrolledsql)
                        AND $usersql";

        $this->sql->params = array_merge($enrolledparams, $userparams, [
            'clevel'     => CONTEXT_USER,
            'courseid'   => $courseid,
            'maxgrade'   => $maxgrade,
        ]);
        
        $this->sql->orderby = 'realgrade DESC, u.id ASC';
    }

    protected function generate_columns_definition() {
        $cols = [
            'userpic' => '',
            'fullname' => get_string('fullname', 'core'),
            'lvl' => get_string('level', 'block_xp'),
            'total' => 'Total',
            'realgrade' => 'Real Grade',
            'gap' => 'Gap',
        ];
        if ($this->world->get_access_permissions()->can_manage()) {
            $cols['actions'] = '';
        }
        return $cols;
    }

    protected function generate_user_filter_sql() {
        $filterset = $this->get_filterset();
        if (!$filterset || !$filterset->has_filter('term')) {
            return ['1=1', []];
        }

        $term = trim($filterset->get_filter('term')->current());
        if (empty($term)) {
            return ['1=1', []];
        }

        $wheres = [];
        $params = [];
        $nameoptions = [['firstname' => $term], ['lastname' => $term]];
        $nameparts = explode(' ', $term);

        if (count($nameparts) > 1) {
            for ($i = 0; $i < count($nameparts) - 1; $i++) {
                $nameoptions[] = [
                    'firstname' => implode(' ', array_slice($nameparts, 0, $i + 1)),
                    'lastname' => implode(' ', array_slice($nameparts, $i + 1)),
                ];
            }
        }

        foreach ($nameoptions as $i => $option) {
            $subsql = [];
            $subparams = [];
            if (!empty($option['firstname'])) {
                $k = 'fn' . $i;
                $subsql[] = $this->db->sql_like('u.firstname', ':' . $k, false, false);
                $subparams[$k] = $this->db->sql_like_escape($option['firstname']) . '%';
            }
            if (!empty($option['lastname'])) {
                $k = 'ln' . $i;
                $subsql[] = $this->db->sql_like('u.lastname', ':' . $k, false, false);
                $subparams[$k] = $this->db->sql_like_escape($option['lastname']) . '%';
            }
            if (!empty($subsql)) {
                $wheres[] = '(' . implode(' AND ', $subsql) . ')';
                $params = array_merge($params, $subparams);
            }
        }

        return empty($wheres) ? ['1=1', []] : ['((' . implode(') OR (', $wheres) . '))', $params];
    }

    final protected function get_columns_definition() {
        if (!isset($this->columnsdefinition)) {
            $this->columnsdefinition = $this->generate_columns_definition();
        }
        return $this->columnsdefinition;
    }

    /**
     * 构建表格 - 直接从数据库获取成绩差距（修复精度问题）
     */
    public function build_table() {
        if (!$this->rawdata) return;

        global $DB;
        $courseid = $this->world->get_courseid();
        
        // 直接从数据库获取去重后的成绩（不受分页影响）
        $sql = "SELECT DISTINCT gg.finalgrade 
                FROM {grade_grades} gg
                JOIN {grade_items} gi ON gi.id = gg.itemid
                WHERE gi.courseid = :courseid 
                    AND gi.itemtype = 'course'
                    AND gg.finalgrade IS NOT NULL
                ORDER BY gg.finalgrade DESC";
        
        $records = $DB->get_records_sql($sql, ['courseid' => $courseid]);
        
        // 计算每个分数与前一名分数的差距
        // 【修改点：计算差距前先四舍五入到2位小数，解决精度问题】
        $gapmap = [];
        $prev = null;
        foreach ($records as $record) {
            // 先四舍五入到2位小数
            $score = round((float)$record->finalgrade, 2);
            $scoreKey = (string)$score;
            
            if ($prev === null) {
                $gapmap[$scoreKey] = null;  // 第一名
            } else {
                $gapmap[$scoreKey] = round($prev - $score, 2);
            }
            $prev = $score;
        }
        
        // 为当前页的每个用户分配差距
        $this->gaps = [];
        foreach ($this->rawdata as $row) {
            $score = round((float)($row->realgrade ?? 0), 2);
            $scoreKey = (string)$score;
            $this->gaps[$row->id] = $gapmap[$scoreKey] ?? null;
        }
        
        // 构建表格行
        foreach ($this->rawdata as $row) {
            $row->state = $this->make_state_from_record($row);
            
            // 修复等级显示：只有100分才是等级10，99.99及以下按正常规则
            $originalGrade = (float)($row->total ?? 0);
            if ($originalGrade >= 100) {
                $row->lvl = 10;
            } else {
                $row->lvl = (int)floor($originalGrade / 10);
                $row->lvl = max(1, min(9, $row->lvl));
            }
            
            $this->add_data_keyed($this->format_row($row), $this->get_row_class($row));
        }
    }

    /**
     * 格式化行数据 - 将所有浮点数转换为字符串，避免隐式转换警告
     */
    public function format_row($row) {
        $row = parent::format_row($row);
        
        $isObject = is_object($row);
        $float_fields = ['realgrade', 'total'];
        
        foreach ($float_fields as $field) {
            if ($isObject) {
                if (property_exists($row, $field) && is_numeric($row->$field)) {
                    $row->$field = number_format((float)$row->$field, 2, '.', '');
                }
            } else {
                if (isset($row[$field]) && is_numeric($row[$field])) {
                    $row[$field] = number_format((float)$row[$field], 2, '.', '');
                }
            }
        }
        
        return $row;
    }

    protected function get_row_actions($row) {
        $actions = [];
        $actions[] = new action_menu_link(
            $this->baseurl,
            new pix_icon('t/edit', get_string('edit', 'core')),
            get_string('edit', 'core'),
            false,
            [
                'data-xp-action' => 'open-form',
                'data-form-class' => 'block_xp\form\user_xp',
                'data-form-args__contextid' => $this->world->get_context()->id,
                'data-form-args__userid' => is_object($row) ? $row->id : $row['id'],
                'data-modal-title' => get_string('edita', 'core', fullname($row)),
            ]
        );

        if ($this->logaccessperms && $this->logaccessperms->can_access_logs()) {
            $url = $this->urlresolver->reverse('log', ['courseid' => $this->world->get_courseid()]);
            $url->param('userid', is_object($row) ? $row->id : $row['id']);
            $actions[] = new action_menu_link($url, new pix_icon('t/log', get_string('logs', 'core')), get_string('viewlogs', 'block_xp'));
        }

        return $actions;
    }

    protected function col_actions($row) {
        $actions = $this->get_row_actions($row);
        return empty($actions) ? '' : $this->renderer->control_menu($actions);
    }

    public function col_fullname($row) {
        $o = parent::col_fullname($row);
        $suspended = is_object($row) ? $row->suspended : $row['suspended'];
        return $suspended ? $o . ' (' . get_string('suspended', 'core') . ')' : $o;
    }

    protected function col_lvl($row) {
        $lvl = is_object($row) ? ($row->lvl ?? null) : ($row['lvl'] ?? null);
        return isset($lvl) ? $lvl : '-';
    }

    protected function col_total($row) {
        if (is_object($row)) {
            return isset($row->total) ? $row->total : '0.00';
        } else {
            return isset($row['total']) ? $row['total'] : '0.00';
        }
    }

    protected function col_realgrade($row) {
        if (is_object($row)) {
            return isset($row->realgrade) ? $row->realgrade : '0.00';
        } else {
            return isset($row['realgrade']) ? $row['realgrade'] : '0.00';
        }
    }

    /**
     * 计算差距 - 直接从 gaps 数组获取
     */
    protected function col_gap($row) {
        $userid = is_object($row) ? $row->id : $row['id'];
        $gap = $this->gaps[$userid] ?? null;
        
        if ($gap === null) {
            return '🥇 No.1';
        }
        
        // 同分情况：差距为 0
        if (abs($gap) < 0.01) {
            return '持平';
        }
        
        return '+' . number_format($gap, 2);
    }

    protected function col_userpic($row) {
        $state = is_object($row) ? ($row->state ?? null) : ($row['state'] ?? null);
        if ($state instanceof state_with_subject) {
            return $this->renderer->user_avatar($state->get_picture(), $state->get_link());
        }
        return '';
    }

    protected function make_state_from_record($row) {
        $record = is_object($row) ? $row : (object)$row;
        return $this->store->make_state_from_record($record, 'id');
    }

    public static function construct_order_by($cols, $textsortcols = []) {
        $newcols = [];
        foreach ($cols as $f => $d) {
            if ($f === 'realgrade') {
                $newcols['realgrade'] = $d;
            } else if ($f === 'lvl') {
                $newcols['COALESCE(total, 0)'] = $d;
            } else {
                $newcols[$f] = $d;
            }
        }
        return parent::construct_order_by($newcols, $textsortcols);
    }

    public function get_sort_columns() {
        $orderby = parent::get_sort_columns();
        if (!empty($orderby)) {
            $orderby['id'] = SORT_ASC;
        }
        return $orderby;
    }

    public function get_sql_sort() {
        return static::construct_order_by($this->get_sort_columns(), []);
    }

    public function out($pagesize, $initialbars, $downloadhelpbutton = '') {
        $this->init_sql();
        return parent::out($pagesize, $initialbars, $downloadhelpbutton);
    }

    public function print_nothing_to_display() {
        echo $this->render_reset_button();
        $msg = $this->can_be_reset() ? get_string('nothingtodisplay', 'core') : get_string('reportisempty', 'block_xp');
        echo \html_writer::div(\block_xp\di::get('renderer')->notification_without_close($msg, 'info'), '', ['style' => 'margin:1em 0']);
    }

}